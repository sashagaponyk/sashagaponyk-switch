<?php

include_once('db.php');



$cost = $_POST['cost']; $id = $_POST['id'];

$sql = "UPDATE cost SET cost='$cost' WHERE id='$id'";


if($mysqli->query($sql)){
    echo "Рядок змінено успішно";
    }
else
    {
        echo "Error" . $sql . "<br/>" . $mysqli->error;
    }




include_once("showCost.php");
?>
