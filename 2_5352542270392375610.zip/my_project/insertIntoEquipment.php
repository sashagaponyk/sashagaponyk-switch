<?php

include_once('db.php');


$equipment = $_POST['equipment'];

$sql = "INSERT INTO equipment (equipment) VALUES ('$equipment' )";


if($mysqli->query($sql)){
    echo "Рядок вставлено успішно";
    }
else
    {
        echo "Error" . $sql . "<br/>" . $mysqli->error;
    }


include_once("showEquipment.php");

?>
