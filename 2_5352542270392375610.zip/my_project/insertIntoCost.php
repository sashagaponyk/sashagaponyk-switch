<?php

include_once('db.php');


$cost = $_POST['cost'];

$sql = "INSERT INTO cost (cost) VALUES ('$cost' )";


if($mysqli->query($sql)){
    echo "Рядок вставлено успішно";
    }
else
    {
        echo "Error" . $sql . "<br/>" . $mysqli->error;
    }


include_once("showCost.php");

?>
