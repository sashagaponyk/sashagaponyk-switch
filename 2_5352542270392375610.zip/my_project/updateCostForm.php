<html>
<head>
    <meta charset="utf-8">
    <meta name="keywords" content="Лабораторна робота, MySQL, з'єднання з базою даних">
    <meta name="description" content="Лабораторна робота. З'єднання з базою даних">
    <title>Вставка даних</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <?php
        include_once("showCost.php");    
    ?>

<form action="updateCost.php" method="post">
        <label>ID рядка</label><input name="id" type="text"><br>
        <label>Cost</label><input name="cost" type="text"><br>
        
        <input type="submit" value="Оновити рядок">
</form>

</body>
</html>