<?php

include_once('db.php');



$equipment = $_POST['equipment']; $id = $_POST['id'];

$sql = "UPDATE equipment SET equipment='$equipment' WHERE id='$id'";


if($mysqli->query($sql)){
    echo "Рядок змінено успішно";
    }
else
    {
        echo "Error" . $sql . "<br/>" . $mysqli->error;
    }




include_once("showEquipment.php");
?>
